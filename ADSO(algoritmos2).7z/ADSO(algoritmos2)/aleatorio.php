<?php
// $aleatorio = time() % 100 + 1;
//echo  "El numero aleatorio entre 01 y 100 es: $aleatorio";

//segundo codigo
class numeroAleatorio{
    public function generar(){
        $aleatorio = (time() % 100) +1;
        return $aleatorio;
    }
}

$generador = new numeroAleatorio();
$aleatorio = $generador -> generar();

echo "El numero aleatorio entre 01 y 100 es: $aleatorio";
?>

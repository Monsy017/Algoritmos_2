<?php

class PrimoFinder {
    public function encontrarPrimos($cantidad, $min, $max) {
        $numerosAleatorios = $this->generarNumerosAleatorios($cantidad, $min, $max);

        echo "Números primos en el conjunto:\n";

        foreach ($numerosAleatorios as $numero) {
            if ($this->esPrimo($numero)) {
                echo "$numero ";
            }
        }
    }

    private function generarNumerosAleatorios($cantidad, $min, $max) {
        $numeros = [];
        for ($i = 0; $i < $cantidad; $i++) {
            $numeros[] = mt_rand($min, $max);
        }
        return $numeros;
    }

    private function esPrimo($numero) {
        if ($numero <= 1) {
            return false;
        }

        for ($i = 2; $i <= sqrt($numero); $i++) {
            if ($numero % $i == 0) {
                return false;
            }
        }

        return true;
    }
}

// Uso del código
$primoFinder = new PrimoFinder();
$primoFinder->encontrarPrimos(1000, 1, 5000000);

?>
<?php

class numeroPrimo{
    private $numero;

    public function __construct($numero) {
        $this->numero = $numero;
    }

    public function esPrimo() {
        if ($this->numero <= 1) {
            return false;
        }

        for ($i = 2; $i <= sqrt($this->numero); $i++) {
            if ($this->numero % $i == 0) {
                return false;
            }
        }

        return true;
    }
}

$numeroDado = 7; 

$verificadorPrimo = new numeroPrimo($numeroDado);

if ($verificadorPrimo->esPrimo()) {
    echo "$numeroDado es un número primo.";
} else {
    echo "$numeroDado no es un número primo.";
}

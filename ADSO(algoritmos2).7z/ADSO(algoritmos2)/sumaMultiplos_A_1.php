<?php

// Primer codigo//
// function sumaMultiplos($limite){
//     $suma = 0;

//     for ($i=0; $i < $limite; $i++) { 
//         if ($i % 3 == 0 || $i % 5 ==0) {
//             $suma += $i;
//         }
//     }
//     return $suma;
// }

// $limiteSuperior = 10;
// $resultado = sumaMultiplos($limiteSuperior);

// echo "la suma de los multiplos de 3 o 5 por debajo de $limiteSuperior es: $resultado";

// Segundo codigo//

class SumaMultiplos
{
    public function calcular($limite)
    {
        $suma = 0;

        for ($i = 0; $i < $limite; $i++) {
            if ($i % 3 == 0 || $i % 5 == 0) {
                $suma += $i;
            }
        }

        return $suma;
    }
}

$limiteSuperior = 10;
$sumaMultiplos = new SumaMultiplos();
$resultado = $sumaMultiplos->calcular($limiteSuperior);

echo "La suma de los múltiplos de 3 o 5 por debajo de $limiteSuperior es: $resultado";